package me.earth.earthhack.impl.core.ducks.gui;

public interface IGuiChat
{
    void accessSetText(String text, boolean shouldOverwrite);

}
