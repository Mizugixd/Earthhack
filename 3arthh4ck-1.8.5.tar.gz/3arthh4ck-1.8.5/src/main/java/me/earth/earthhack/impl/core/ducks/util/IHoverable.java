package me.earth.earthhack.impl.core.ducks.util;

// This is cool but got kinda unnecessary...
public interface IHoverable
{
    default boolean canBeHovered()
    {
        return true;
    }
}
