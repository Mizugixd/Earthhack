package me.earth.earthhack.api.config;

import me.earth.earthhack.api.util.interfaces.Nameable;

public interface Config extends Nameable
{
    void apply();

}
