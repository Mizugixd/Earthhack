package me.earth.earthhack.impl.commands.gui;

import net.minecraft.client.gui.GuiScreen;

// TODO: THIS!
public class ConsoleScreen extends GuiScreen
{

}
