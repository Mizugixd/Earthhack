package me.earth.earthhack.impl.event.events.network;

public class PreMotionUpdateEvent {
}
