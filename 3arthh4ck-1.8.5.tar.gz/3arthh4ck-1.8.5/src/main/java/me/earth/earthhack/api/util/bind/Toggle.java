package me.earth.earthhack.api.util.bind;

public enum Toggle
{
    Normal,
    Hold,
    Disable
}
