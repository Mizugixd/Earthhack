package me.earth.earthhack.impl.core.ducks.network;

public interface ISPacketSpawnObject {
    void setAttacked(boolean attacked);

    boolean isAttacked();

}
