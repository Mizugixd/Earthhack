package me.earth.earthhack.impl.core.ducks.util;

public interface IKeyBinding {

    void setPressed(boolean pressed);
}
