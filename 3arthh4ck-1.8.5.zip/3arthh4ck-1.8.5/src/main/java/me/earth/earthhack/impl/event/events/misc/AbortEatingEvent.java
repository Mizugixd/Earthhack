package me.earth.earthhack.impl.event.events.misc;

import net.minecraft.entity.player.EntityPlayer;

/**
 * Doesn't necessarily mean eating,
 * you need to check via
 * {@link EntityPlayer#getActiveItemStack()}.
 */
public class AbortEatingEvent { }
