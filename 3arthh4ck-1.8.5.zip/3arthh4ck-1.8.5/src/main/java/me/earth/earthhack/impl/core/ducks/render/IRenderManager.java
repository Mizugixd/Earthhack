package me.earth.earthhack.impl.core.ducks.render;

public interface IRenderManager
{
    double getRenderPosX();

    double getRenderPosY();

    double getRenderPosZ();

}
