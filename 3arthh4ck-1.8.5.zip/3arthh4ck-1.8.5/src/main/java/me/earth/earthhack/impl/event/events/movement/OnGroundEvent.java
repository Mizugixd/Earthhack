package me.earth.earthhack.impl.event.events.movement;

import me.earth.earthhack.api.event.events.Event;

public class OnGroundEvent extends Event
{
}
